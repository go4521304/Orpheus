#include "stdfx.h"
#include "GameObject.h"
#include "GameFramework.h"


/********************************** Main **********************************/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPreInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;

	WNDCLASSEX WndClass;
	g_hInst = hInstance;

	WndClass.cbSize = sizeof(WndClass);
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc = (WNDPROC)WndProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = g_hInst;
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.lpszMenuName = NULL;
	WndClass.lpszClassName = lpszClass;
	WndClass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

	RegisterClassEx(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME,
		0, 0, win_x_size + 14, win_y_size + 36, NULL, (HMENU)NULL, g_hInst, NULL);

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);


	while (true)
	{
		::PeekMessage(&Message, 0, 0, 0, PM_REMOVE);
		if (Message.message == WM_QUIT ||
			Message.message == WM_CLOSE ||
			Message.message == WM_DESTROY)
			break;

		::TranslateMessage(&Message);
		::DispatchMessage(&Message);
	}

	return Message.wParam;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	HDC hdc, memdc;
	PAINTSTRUCT ps;

	HBRUSH hbrush, oldbrush;
	HPEN hpen, oldpen;

	CImage img;
	CImage dc;

	HFONT hFont, oldFont;

	TCHAR str[500] = {};

	switch (uMsg)
	{
	case WM_CREATE:
	{
		InitSet();
		/////////////////////////////////////////////////////////////////////////////////////////
	}
	break;

	case WM_GETMINMAXINFO:
	{
		((MINMAXINFO *)lParam)->ptMaxTrackSize.x = win_x_size + 14;
		((MINMAXINFO *)lParam)->ptMaxTrackSize.y = win_y_size + 36;
		((MINMAXINFO *)lParam)->ptMinTrackSize.x = win_x_size + 14;
		((MINMAXINFO *)lParam)->ptMinTrackSize.y = win_y_size + 36;
		return false;
	}
	break;

	case WM_PAINT: // ������
	{
		hdc = BeginPaint(hWnd, &ps);

		if (true)
		{
			dc.Create(win_x_size, win_y_size, 24);	// ��� ���� DC
			memdc = dc.GetDC();					// ��� ���� DC

			////////////////////////////////////////// Render ///////////////////////////////////////////////

			for (const auto &gameobj : gameObject[sceneCount])
			{
				gameobj->Render(memdc);
			}

			TCHAR script[1000] = {};   //�Ѿ˰���

			hbrush = CreateSolidBrush(RGB(255, 255, 255));
			oldbrush = (HBRUSH)SelectObject(memdc, hbrush);

			// ù��° �Ķ���Ͱ� ��Ʈ ũ��, �������� ��Ʈ �Է��ϸ� �� �� ����
			hFont = CreateFont(50, 0, 0, 0, FW_NORMAL, 0, 0, 0, 0, 0, 0, 0, 0, TEXT("arial"));
			oldFont = (HFONT)SelectObject(memdc, hFont);

			// ���� ��ġ ������� (����, ���, ������, �ϴ�)
			RECT print_rect{100, win_y_size / 4 * 3, win_x_size - 100, win_y_size};
			wsprintf(script, TEXT("%s"), gameScript[sceneCount]);

			SetBkMode(memdc, TRANSPARENT);  //�������
			DrawText(memdc, script, _tcslen(script), &print_rect, DT_VCENTER);
			SelectObject(memdc, oldbrush);
			DeleteObject(hbrush);
			SelectObject(memdc, oldFont);
			DeleteObject(hFont);

			dc.Draw(hdc, 0, 0, win_x_size, win_y_size);	// �Ʒ��� Bitblt�� ����
			dc.ReleaseDC();		// dc ����
			dc.Destroy();		// ��� dc ����
		}

		EndPaint(hWnd, &ps);
	}
	break;

	case WM_LBUTTONDOWN:
	{
		sceneCount++;
		sceneCount %= gameObject.size();
		InvalidateRect(hWnd, NULL, false);
	}
	break;

	case WM_LBUTTONUP:
	{

	}
	break;

	case WM_MOUSEMOVE:
	{
	}
	break;

	case WM_KEYDOWN:
	{


	}
	break;

	case WM_KEYUP:
	{

	case VK_SPACE:
		break;
	}
	break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}