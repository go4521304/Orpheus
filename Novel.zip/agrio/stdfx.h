#pragma once
#include <cstdlib>
#include <windows.h>
#include <tchar.h>
#include <atlimage.h>
#include <iostream>
#include <vector>
#include <map>