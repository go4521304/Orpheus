#pragma once

#include "stdfx.h"

/******************************************** �Լ� ********************************************/

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);